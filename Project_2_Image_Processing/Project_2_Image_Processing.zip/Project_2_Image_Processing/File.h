#include "Pixel.h"
#include <vector>
#include <cstdlib>
#include <string>
#include <iostream>
#include <fstream>


using namespace std;

struct Header
{
	char idLength;
	char colorMapType;
	char dataTypeCode;
	short colorMapOrigin;
	short colorMapLength;
	char colorMapDepth;
	short xOrigin;
	short yOrigin;
	short width;
	short height;
	char bitsPerPixel;
	char imageDescriptor;


};


class File {
public:
	Header fileHeader;
	vector<Pixel> Pixels;
	//File();
	File(string filename); //Basic function that calls Read and stores data

	File(string filename, string channel, string rotate); //Reads file and seperates color channels

	vector<Pixel> GetPixels();

	void Read(ifstream& myFile);
	void Write(string outName, vector<Pixel> pixels, Header& obj);
	bool Verify(vector<Pixel> a, string name);

	int numPixels;




};