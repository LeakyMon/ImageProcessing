#include <string>
#include <iostream>
#include <fstream>
#include <ostream>
#include <sstream>
#include <vector>
#include "File.h"
#include "Pixel.h"
using namespace std;

const float f = 0.5f;

//FUNCTIONS
void CompleteTask(int task);

bool Verify(vector<Pixel> a, string name);

void Multiply(File& obj, File& obj2, string fileOut);

void Subtract(File& obj, File& obj2, string fileOut);

void Overlay(File& obj, File& obj2, string fileOut);

void MultAndSub(File& obj, File& obj2, File& obj3, string fileOut);

void Screen(File& obj, File& obj2, string fileout);

void ChannelManip(File& obj, int option, string fileout);

void Combine(File& obj, File& obj2, File& obj3, string fileout);

void Rotate(File& obj, string fileout);

int option = 0;
//READ AND STORE FILES
File layer1("input/layer1.tga");
File layer2("input/layer2.tga");

File layerBlue("input/layer_blue.tga");
File layerRed("input/layer_red.tga");
File layerGreen("input/layer_green.tga");

File pattern1("input/pattern1.tga");
File pattern2("input/pattern2.tga");

File text("input/text.tga");
File text2("input/text2.tga");

File circle("input/circles.tga");
File car("input/car.tga");

vector<Pixel> function;
vector<Pixel> combo;
vector<Pixel> rotateFunction;

int main() {
	int num = 0;
	
	//Initializes the vector with 262144 values to later be replaced
	for (int i = 0; i < 262144; i++) {


		Pixel curr;
		curr.blue = i;
		curr.red = i;
		curr.green = i;
		
		
		function.push_back(curr);
		num++;
	}

	for (int i = 0; i < 262144; i++) {


		Pixel curr;
		curr.blue = i;
		curr.red = i;
		curr.green = i;


		combo.push_back(curr);
		num++;
	}

	for (int i = 0; i < 262144; i++) {


		Pixel curr;
		curr.blue = i;
		curr.red = i;
		curr.green = i;


		rotateFunction.push_back(curr);
		num++;
	}

	
	//TASKS 1-10
	CompleteTask(1);

	CompleteTask(2);

	CompleteTask(3);

	CompleteTask(4);

	CompleteTask(5);
	
	CompleteTask(6);
	
	CompleteTask(7);

	//CompleteTask(8);

	//CompleteTask(9);

	//CompleteTask(10);

	cout << "FINISH";

	return 0;

}

void CompleteTask(int task)
{

	vector<Pixel> firstFile;
	vector <Pixel> secondFile;

	
	if (task == 1) {

		//MULTIPLY
		string fileOut = "output/part1.tga";
		string exFile = "examples/EXAMPLE_part1.tga";

		Multiply(layer1, pattern1, fileOut);



		if (Verify(function, exFile) == true) {

			cout << "Task 1 Successful" << endl;

		}
		else {

			cout << "Task 1 Failed" << endl;

		}

	}

	else if (task == 2) {

	
		string fileOut = "output/part2.tga";
		string exFile = "examples/EXAMPLE_part2.tga";

		Subtract(layer2, car, fileOut);

		if (Verify(function, exFile) == true) {

			cout << "Task 2 Successful" << endl;

		}
		else {

			cout << "Task 2 Failed" << endl;

		}

	}
	else if (task == 3) {

		
		
		string outFile = "output/part3.tga";
		string exFile = "examples/EXAMPLE_part3.tga";


		Multiply(layer1, pattern2, outFile);
		Screen(layer1, text, outFile);

		if (Verify(function, exFile) == true) {

			cout << "Task 3 Successful" << endl;

		}
		else {

			cout << "Task 3 Failed" << endl;

		}


	}
	else if (task == 4) {

		

		string outFile = "output/part4.tga";
		string exFile = "examples/EXAMPLE_part4.tga";

		Multiply(layer2, circle, outFile);
		option = 1;
		Subtract(pattern2, circle, outFile);
	
		
		if (Verify(function, exFile) == true) {

			cout << "Task 4 Successful" << endl;

		}
		else {

			cout << "Task 4 Failed" << endl;

		}


	}
	else if (task == 5) {

		string outFile = "output/part5.tga";
		string exFile = "examples/EXAMPLE_part5.tga";

		Overlay(layer1, pattern1, outFile);

		if (Verify(function, exFile) == true) {

			cout << "Task 5 Successful" << endl;

		}
		else {

			cout << "Task 5 Failed" << endl;

		}


	}

	else if (task == 6) { //Add 200 Green to car.tga

		string outFile = "output/part6.tga";
		string exFile = "examples/EXAMPLE_part6.tga";
		
		ChannelManip(car, 1, outFile);

		if (Verify(function, exFile) == true) {

			cout << "Task 6 Successful" << endl;

		}
		else {

			cout << "Task 6 Failed" << endl;

		}

	}
	else if (task == 7) {

		string outFile = "output/part7.tga";
		string exFile = "examples/EXAMPLE_part7.tga";

		ChannelManip(car, 2, outFile);

		if (Verify(function, exFile) == true) {

			cout << "Task 7 Successful" << endl;

		}
		else {

			cout << "Task 7 Failed" << endl;

		}

	}
	else if (task == 8) {

		string r = "red";
		string b = "blue";
		string g = "green";
		string rotate = "NOrotate";
		File TaskEightB("input/car.tga", b, rotate);
		File TaskEightG("input/car.tga", g, rotate);
		File TaskEightR("input/car.tga", r, rotate);
		//string exFileB = "examples/EXAMPLE_part8_b";
		
		

		/*if (Verify(function, exFileB) == true) {
			cout << "Task 8b Successful" << endl;
		}
		else {
			cout << "Task 8b Failed" << endl;
		}
		string exFileG = "examples/EXAMPLE_part8_g";
		

		if (Verify(function, exFileG) == true) {
			cout << "Task 2 Successful" << endl;
		}
		else {
			cout << "Task 2 Failed" << endl;
		}

		string exFileR = "examples/EXAMPLE_part8_r";
		

		if (Verify(function, exFileR) == true) {
			cout << "Task 2 Successful" << endl;
		}
		else {
			cout << "Task 2 Failed" << endl;
		}*/




	}
	else if (task == 9) {

		string outFile = "output/part9.tga";
		string exFile = "examples/EXAMPLE_part9.tga";
		
		Combine(layerBlue, layerGreen, layerRed, outFile);

		if (Verify(combo, exFile) == true) {
			cout << "Task 9 Successful" << endl;
		}
		else {
			cout << "Task 9 Failed" << endl;
		}

	}
	else if (task == 10) {

		string rotate = "rotate";
		string b = "x";
		//File Task10Flip("input/text2.tga", b, rotate);
		string outFile = "output/part10.tga";
		string exFile = "examples/EXAMPLE_part10";
		Rotate(text2, outFile);

		if (Verify(rotateFunction, exFile) == true) {
			cout << "Task 2 Successful" << endl;
		}
		else {
			cout << "Task 2 Failed" << endl;
		}


	}
}



void Multiply(File& first, File& second,  string outFile)
{

	if (option == 1) {
		

	}

	Header obj;
	float resultBlue;
	float resultGreen;
	float resultRed;


	vector<Pixel> firstFile;
	vector <Pixel> secondFile;

	firstFile = first.GetPixels();

	secondFile = second.GetPixels();

	//firstFile = function;

	int num = 0;
	for (int i = 0; i < firstFile.size(); i++) {
		Pixel curr;

		//Divide color by 255 to set equal to 1 to operate on
		float blue1;
		blue1 = (float)firstFile.at(i).blue;
		blue1 /= 255;
		float blue2;
		blue2 = (float)secondFile.at(i).blue;
		blue2 /= 255;
		resultBlue = (blue1 * blue2 * 255) + f;

		curr.blue = (unsigned int)resultBlue;

		//bVector.push_back(b);

		float green1;
		green1 = (float)firstFile.at(i).green;
		green1 /= 255;
		float green2;
		green2 = (float)secondFile.at(i).green;
		green2 /= 255;
		resultGreen = (green1 * green2 * 255) + f;

		curr.green = (unsigned char)resultGreen;

		//gVector.push_back(g);


		float red1;
		red1 = (float)firstFile.at(i).red;
		red1 /= 255;
		float red2;
		red2 = (float)secondFile.at(i).red;
		red2 /= 255;
		resultRed = (red1 * red2 * 255) + f;

		curr.red = (unsigned char)resultRed;


		function.at(i) = (curr);

	}
	cout << num;

	//Subtract(first, second, outFile);
	first.Write(outFile, function, obj);

}

void Subtract(File& first, File& second, string outFile)
{

	Header obj;
	float resultBlue;
	float resultGreen;
	float resultRed;


	vector<Pixel> firstFile;
	vector<Pixel> secondFile;


	firstFile = first.GetPixels();
	secondFile = second.GetPixels();

	if (option == 1){
	
		secondFile = function;

	}
	
	

	//firstFile = function;

	// SUBTRACT METHOD
	for (int i = 0; i < firstFile.size(); i++) {

		float blue1;
		blue1 = (float)firstFile.at(i).blue;
		float blue2;
		blue2 = (float)secondFile.at(i).blue;
		resultBlue = blue2 - blue1;

		float green1;
		green1 = (float)firstFile.at(i).green;
		float green2;
		green2 = (float)secondFile.at(i).green;
		resultGreen = green2 - green1;

		float red1;
		red1 = (float)firstFile.at(i).red;
		float red2;
		red2 = (float)secondFile.at(i).red;
		resultRed = red2 - red1;



		if (resultBlue > 255) {
			resultBlue = 255;
		}
		if (resultBlue < 0) {
			resultBlue = 0;
		}
		if (resultGreen > 255) {
			resultGreen = 255;
		}
		if (resultGreen < 0) {
			resultGreen = 0;
		}
		if (resultRed > 255) {
			resultRed = 255;
		}
		if (resultRed < 0) {
			resultRed = 0;
		}
		//Pixel currPixel;
		Pixel curr;

		curr.blue = (unsigned char)resultBlue;
		curr.green = (unsigned char)resultGreen;
		curr.red = (unsigned char)resultRed;

		function.at(i) = (curr);

	}
	first.Write(outFile, function, obj);




	
}

void Overlay(File& first, File& second, string fileOut)
{

	Header obj;
	float resultBlue;
	float resultGreen;
	float resultRed;


	vector<Pixel> firstFile;
	vector<Pixel> secondFile;


	firstFile = first.GetPixels();
	secondFile = second.GetPixels();


	for (int i = 0; i < (int)firstFile.size(); i++) {
		float resultBlue;
		float resultGreen;
		float resultRed;
		
		float blue1;
		blue1 = (float)firstFile.at(i).blue / 255;
		float blue2;
		blue2 = (float)secondFile.at(i).blue / 255;

		float green1;
		green1 = (float)firstFile.at(i).green / 255;
		float green2;
		green2 = (float)secondFile.at(i).green / 255;

		float red1;
		red1 = (float)firstFile.at(i).red / 255;
		float red2;
		red2 = (float)secondFile.at(i).red / 255;


		if (blue2 <= 0.5) {
			resultBlue = (2 * blue1 * blue2 * 255) + f;
		}
		else {
			resultBlue = ((1 - 2 * ((1 - blue1) * (1 - blue2))) * 255) + 0.5f;
			if ((resultBlue) < 0) {
				resultBlue = 0;
			}
			else if ((resultBlue) > 255) {
				resultBlue = 255;
			}
		}
		if (green2 <= 0.5) {
			resultGreen = (2 * green1 * green2 * 255) + 0.5f;

		}
		else {
			resultGreen = ((1 - 2 * ((1 - green1) * (1 - green2))) * 255) + 0.5f;
			if (((resultGreen) < 0)) {
				resultGreen = 0;
			}
			else if (green2 - green1 > 255) {
				resultGreen = 255;
			}
		}
		if (red2 <= 0.5) {
			resultRed = (2 * red1 * red2 * 255) + 0.5f;
		}
		else {
			resultRed = ((1 - 2 * ((1 - red1) * (1 - red2))) * 255) + 0.5f;
			if ((resultRed) < 0) {
				resultRed = 0;
			}
			else if ((resultRed) > 255) {
				resultRed = 255;
			}
		}

		Pixel curr;
		curr.blue = (unsigned char)resultBlue;
		curr.green = (unsigned char)resultGreen;
		curr.red = (unsigned char)resultRed;
		function.at(i) = (curr);

	}
	layer1.Write(fileOut, function, obj);



}

void MultAndSub(File& first, File& second, File& third, string fileOut)
{
	Header obj;
	float resultBlue;
	float resultGreen;
	float resultRed;


	vector<Pixel> firstFile;
	vector <Pixel> secondFile;

	firstFile = first.GetPixels();
	
	secondFile = second.GetPixels();

	//firstFile = function;

	int num = 0;
	for (int i = 0; i < firstFile.size(); i++) {
		Pixel curr;

		//Divide color by 255 to set equal to 1 to operate on
		float blue1;
		blue1 = (float)firstFile.at(i).blue;
		blue1 /= 255;
		float blue2;
		blue2 = (float)secondFile.at(i).blue;
		blue2 /= 255;
		resultBlue = (blue1 * blue2 * 255) + f;

		curr.blue = (unsigned int)resultBlue;

		//bVector.push_back(b);

		float green1;
		green1 = (float)firstFile.at(i).green;
		green1 /= 255;
		float green2;
		green2 = (float)secondFile.at(i).green;
		green2 /= 255;
		resultGreen = (green1 * green2 * 255) + f;

		curr.green = (unsigned char)resultGreen;

		//gVector.push_back(g);


		float red1;
		red1 = (float)firstFile.at(i).red;
		red1 /= 255;
		float red2;
		red2 = (float)secondFile.at(i).red;
		red2 /= 255;
		resultRed = (red1 * red2 * 255) + f;
		curr.red = (unsigned char)resultRed;

		function.at(i) = (curr);

	}

	firstFile = third.GetPixels();
	secondFile = function;
	for (int i = 0; i < firstFile.size(); i++) {

		float blue1;
		blue1 = (float)firstFile.at(i).blue;
		float blue2;
		blue2 = (float)secondFile.at(i).blue;
		resultBlue = blue2 - blue1;

		float green1;
		green1 = (float)firstFile.at(i).green;
		float green2;
		green2 = (float)secondFile.at(i).green;
		resultGreen = green2 - green1;

		float red1;
		red1 = (float)firstFile.at(i).red;
		float red2;
		red2 = (float)secondFile.at(i).red;
		resultRed = red2 - red1;



		if (resultBlue > 255) {
			resultBlue = 255;
		}
		if (resultBlue < 0) {
			resultBlue = 0;
		}
		if (resultGreen > 255) {
			resultGreen = 255;
		}
		if (resultGreen < 0) {
			resultGreen = 0;
		}
		if (resultRed > 255) {
			resultRed = 255;
		}
		if (resultRed < 0) {
			resultRed = 0;
		}
		//Pixel currPixel;
		Pixel curr;

		curr.blue = (unsigned char)resultBlue;
		curr.green = (unsigned char)resultGreen;
		curr.red = (unsigned char)resultRed;

		function.at(i) = (curr);

	}
	first.Write(fileOut, function, obj);

}

void Screen(File & first, File & second, string outFile)
{
	Header obj;
	float resultBlue;
	float resultGreen;
	float resultRed;


	vector<Pixel> firstFile;
	vector <Pixel> secondFile;

	firstFile = first.GetPixels();
	
	secondFile = second.GetPixels();

	firstFile = function;

	for (int i = 0; i < (int)firstFile.size(); i++) {
		float blue1;
		blue1 = (float)firstFile.at(i).blue / 255;
		float blue2;
		blue2 = (float)secondFile.at(i).blue / 255;

		float green1;
		green1 = (float)firstFile.at(i).green / 255;
		float green2;
		green2 = (float)secondFile.at(i).green / 255;

		float red1;
		red1 = (float)firstFile.at(i).red / 255;
		float red2;
		red2 = (float)secondFile.at(i).red / 255;

		resultBlue = ((1 - (1 - blue1) * (1 - blue2)) * 255) + f;
		resultGreen = ((1 - (1 - green1) * (1 - green2)) * 255) + f;
		resultRed = ((1 - (1 - red1) * (1 - red2)) * 255) + f;

		Pixel curr;
		curr.blue = (unsigned char)resultBlue;
		curr.green = (unsigned char)resultGreen;
		curr.red = (unsigned char)resultRed;
		function.at(i) = (curr);

	}


	first.Write(outFile, function, obj);
}

void ChannelManip(File& first, int selection, string fileout)
{

	Header obj;
	float resultBlue;
	float resultGreen;
	float resultRed;

	float AddGreen = 200.0f;

	vector<Pixel> firstFile;

	 //Add 200 to Green
		

	firstFile = first.GetPixels();

	for (int i = 0; i < firstFile.size(); i++) {

		
		if (selection == 1) {

			float green = (float)firstFile.at(i).green;
			float red = (float)firstFile.at(i).red;
			float blue = (float)firstFile.at(i).blue;

			float resultBlue = blue;
			float resultGreen = green + AddGreen; //+ AddGreen
			float resultRed = red;

			if (resultGreen > 255) {
				resultGreen = 255;
			}

			Pixel currPixel;
			currPixel.blue = (unsigned char)resultBlue;
			currPixel.green = (unsigned char)resultGreen;
			currPixel.red = (unsigned char)resultRed;
			function.at(i) = (currPixel);

		}
		else {

			float green = (float)firstFile.at(i).green;

			float red = ((float)firstFile.at(i).red / 255.0f) * 4.0f * 255.0f;
			float blue = (float)firstFile.at(i).blue * 0.0f;

			float resultBlue = blue;
			float resultGreen = green;
			float resultRed = red;

			if (resultRed > 255) {
				resultRed = 255;
			}
			Pixel currPixel;
			currPixel.blue = (unsigned char)resultBlue;
			currPixel.green = (unsigned char)resultGreen;
			currPixel.red = (unsigned char)resultRed;
			function.at(i) = (currPixel);


		}

	}
	first.Write(fileout, function, obj);
	
}

void Combine(File& first, File& second, File& third, string fileout)
{

	Header obj;
	float resultBlue;
	float resultGreen;
	float resultRed;

	
	vector<Pixel> firstFile;
	vector <Pixel> secondFile;
	vector<Pixel> thirdFile;

	firstFile = first.GetPixels();
	secondFile = second.GetPixels();
	thirdFile = third.GetPixels();

	//firstFile = function;

	int num = 0;
	for (int i = 0; i < firstFile.size(); i++) {
		Pixel curr;

		float blue;
		blue = (float)firstFile.at(i).blue;
		float green;
		green = (float)secondFile.at(i).green;
		float red;
		red = (float)thirdFile.at(i).red;
		

		float resultBlue;
		resultBlue = blue;
		float resultGreen;
		resultGreen = green;
		float resultRed;
		resultRed = red;

		
		curr.blue = (unsigned char)resultBlue;
		curr.green = (unsigned char)resultGreen;
		curr.red = (unsigned char)resultRed;
		//function.at(i) = (curr);
		combo.at(i) = curr;
		//combo.push_back(curr);

	}

	first.Write(fileout, combo, obj);

}

void Rotate(File& first, string fileout)
{

	Header obj;
	float resultBlue;
	float resultGreen;
	float resultRed;

	
	vector<Pixel> firstFile;
	

	firstFile = first.GetPixels();

	for (int i = (int)firstFile.size() - 1; i > 0; i--) {
		Pixel curr;
		float green;
		green = (float)firstFile.at(i).green;
		float red;
		red = (float)firstFile.at(i).red;
		float blue;
		blue = (float)firstFile.at(i).blue;

		float resultBlue = blue;
		float resultGreen = green;
		float resultRed = red;
		
		curr.blue = (unsigned char)resultBlue;
		curr.green = (unsigned char)resultGreen;
		curr.red = (unsigned char)resultRed;
		//rotateFunction.push_back(curr);
		rotateFunction.at(i) = (curr);
	
	}
	first.Write(fileout, rotateFunction, obj);


}

bool Verify(vector<Pixel> a, string name)
{
	File example1(name);
	vector <Pixel> example;
	example = example1.GetPixels();

	for (int i = 0; i < (int)a.size(); i++) {
		if (a.at(i) == example.at(i)) {

		}
		else {
			return false;
		}
	}

	return true;
}



