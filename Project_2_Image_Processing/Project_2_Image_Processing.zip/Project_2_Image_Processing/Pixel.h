
#pragma once
#include <vector>
using namespace std;


struct Pixel {
	unsigned char blue;
	unsigned char green;
	unsigned char red;

	bool operator==(const Pixel& rhs) const;
};


