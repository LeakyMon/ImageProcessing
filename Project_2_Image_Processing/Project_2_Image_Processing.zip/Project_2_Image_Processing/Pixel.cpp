#include "Pixel.h"


bool Pixel::operator==(const Pixel& rhs) const {
	if (this->blue != rhs.blue || this->green != rhs.green || this->red != rhs.red) {

		return false;
	}
	return true;
}